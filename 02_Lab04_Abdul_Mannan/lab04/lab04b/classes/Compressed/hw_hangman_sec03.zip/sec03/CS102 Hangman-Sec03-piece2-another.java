//  O�ulcan �etinkaya
//  Furkan Ba�kaya
//  Sarp Ula� Kaya
//  Atakan Sa�lam
//  P�nar Y�cel
 
public class Hangman
{
  //properties
  private StringBuffer secretWord;
  private StringBuffer allLetters;
  private StringBuffer usedLetters;
  private int numberOfIncorrectTries;
  private int maxAllowedIncorrectTries;
  private StringBuffer knownSoFar;  
  
  //constructors
  public Hangman()
  {
    this.secretWord = new StringBuffer(chooseSecretWord());    
    this.allLetters = new StringBuffer("ABCDEFGHIJKLMNOPQRSTUVWYXZ");
    this.maxAllowedIncorrectTries = 6;
    this.numberOfIncorrectTries = 0;
    this.usedLetters = new StringBuffer("");
    this.knownSoFar = new StringBuffer("");
    
    for ( int i = 0; i < secretWord.length(); i++)
    {
      this.knownSoFar.append('*');
    }
    
  }  
}