/**
 * Chooses a word from the pre-arranged list.
 * @author Hasan Y�ld�r�m, �brahim Karako�, F�rat Yonak, Metehan G�rb�z, 
 * Selcen Kaya, Selin K�rmac�
 * @version 13/02/19
 */
public class SecretWord
{
   // properties
   String[] listOfWords = {"a", "b", "c", "d", "e"};
   
   // constructors
   public SecretWord()
   {
   }
   
   // methods
   public String chooseSecretWord()
   {
      int n;
      n = (int) (Math.random() * listOfWords.length);
      return listOfWords[n];
   }
}