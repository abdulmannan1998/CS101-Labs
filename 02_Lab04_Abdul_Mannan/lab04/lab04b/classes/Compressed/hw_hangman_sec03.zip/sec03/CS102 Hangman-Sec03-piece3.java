/*
 * Elif Gamze G�liter
 * Onur Oru�
 * Asya Do�a �zer
 * �rem Tekin
 * Melike Demirci
 * Umut Ada Y�r�ten
 * */
public class TryThis
{
  public int tryThis( char letter)
  {
    int count;
    count = 0;
    int[] position;
    position = new int[secretWord.length()];
    
    for (int i = 0; i < usedletters.length(); i++)
    {
      if (usedletters.charAt(i) == letters)
      {
        return -2;
      }
    }
    
    for (int i = 0; i < secretWord.length(); i++)
    {
      if( secretWord.charAt(i) == letter)
      {
        position[i] = 1;
        count++;
      }
    }
    
    
    for ( int i = 0; i < knownSoFar.length(); i++)
    {
      if ( position[i] == 1)
      {
        knownSoFar.setCharAt( i, letter)
      }
    }
    
    if (isGameOver())
      return -3;
    
    if ( count == 0)
    {
      numberOfIncorrectTries++;
      return -1;
    }
    
    usedletters = usedletters + letter;
    return count;
  }
}