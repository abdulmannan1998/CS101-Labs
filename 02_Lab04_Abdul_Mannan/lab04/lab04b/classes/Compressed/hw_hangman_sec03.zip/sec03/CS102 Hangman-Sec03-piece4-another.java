// Group Members : Osman Bu�ra Ayd�n, �mer Yavuz �zt�rk, Muhammed Do�ancan Y�lmazo�lu, Mustafa Tuna Acar, Ertu�rul Akta�, Kutsal Bek�i, Yahya Mohammed 
import java.io.*;
import java.util.ArrayList;
public class Hangman
{
   // properties
   StringBuffer secretWord;
   StringBuffer allLetters;
   StringBuffer usedletters; 
   int numberOfIncorrectTries; 
   int maxAllowedIncorrectTries; 
   StringBuffer knownSoFar;
   
   // For the first part
   String[] list;
   
   // For the second part (taking from file)
   File file; 
   BufferedReader reader ; 
   String info;
   ArrayList<String> textList;
      
      // constructors
      
      public Hangman(){
      
      list = new String[7];
      
      list[0] = "car";
      list[1] = "computer";
      list[2] = "screen";
      list[3] = "java";
      list[4] = "David";
      list[5] = "break";
      list[6] = "dance";
      
   }
   
   // methods
   
   public String chooseSecretWord(){
      
      int random;
      random = (int) (list.length * Math.random());
      return list[random];
      
   }
   
   /* This part doesnt work properly
   public String chooseSecretWordFromText(){
      
      int random;
      file = new File("C:\\Users\\ertugrul.aktas-ug\\Desktop\\Hangman\\words.txt"); 
      reader = new BufferedReader(new FileReader(file));
      textList = new ArrayList<>();
      while ((info = reader.readLine()) != null) 
         textList.add(info);
      
      random = (int) (textList.size() * Math.random());
      return textList.get(random);
      
   }
   */
}