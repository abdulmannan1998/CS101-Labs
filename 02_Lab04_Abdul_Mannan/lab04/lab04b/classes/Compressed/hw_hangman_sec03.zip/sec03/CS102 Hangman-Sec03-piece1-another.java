/**
 * Burak Yi�it Uslu
 * Can K�r�all�oba
 * Can K�r�mca
 * Sena Sultan Karata�
 * Arda Ak�a B�y�k
 * Bar�� Tiftik
 */ 

import java.util.Scanner;

public class HangmanMain
{
   public static void main( String[] args)
   {      
      Scanner scan = new Scanner( System.in);
   
      //constants
      
      //variables
      Hangman hangman;
      char letter;
      int bodyPart;
      boolean hasLost;
      boolean isGameOver;
      
      //program code             
      do
      {      
         hangman = new Hangman();
         
         do
         {
            bodyPart = hagman.getNumOfIncorrectTries();
            
            System.out.println( hangman.getAllLetters() );
            
            if ( !hangman.getUsedLetters.equals( "") )
               System.out.println( hangman.getUsedLetters() );
            
            System.out.println( hangman.getKnownSoFar() );
            
            letter = scan.next();
           
            if ( hangman.tryThis( letter) == -1 )
               System.out.println( "Not valid!" );
            else if ( hangman.tryThis( letter) == -2 )
               System.out.println( "Letter already used!" );
            else if ( hangman.tryThis( letter) == -3 )
               hasLost = hangman.hasLost();
            
         } while( !hasLost );
         
         hangman = null; //depends on constructor
         isGameOver = hangman.isGameOver();
      } while ( !isGameOver );
   
   