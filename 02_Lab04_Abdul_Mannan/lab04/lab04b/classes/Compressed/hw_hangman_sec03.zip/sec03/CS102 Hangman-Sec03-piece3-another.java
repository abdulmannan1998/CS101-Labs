/**
 * CS 102 Homework Section 3
 * Ahmet Feyzi Hala�
 * G�kt�� G�rb�zt�rk
 * Lamia Ba�ak Ama�
 * Serdar Somuncuo�lu
 * Aybars Alt�n���k
 * Ege �ahin
 */
public int tryThis(char letter)
{
   int count;
   count = 0;
   boolean found;
   found = false;
   for(int a = 0; a < usedLetters.length(); a++)
   {
      if ( letter.equals(usedLetters.charAt(a)))
      {
         found = true;
         return -2;
      }      
   }
   if ( !found )
   {
      for(int i = 0; i < secretWord.length(); i++)
      {
         if ( letter.equals(secretWord.charAt(i)))
         {
            knownSoFar.replace(i,i+1,letter);
            count++;
         }      
      }
      if ( count == 0 )
      {
         return -1;
      }
      else if( knownSoFar.equals(secretWord))
      {
         return -3;
      }
      else
      {
         return count;
      }      
   }
   usedLetters.append(letter);
}
