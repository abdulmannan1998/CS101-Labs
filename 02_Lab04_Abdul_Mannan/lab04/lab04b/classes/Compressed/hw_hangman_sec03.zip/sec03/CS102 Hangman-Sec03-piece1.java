import java.util.Scanner; 

public class HangGame {
   /*
    * Yi�it G�rses
    * �mer �nl�soy 
    * �ebnem Uslu
    * Defne �ift�i
    * Gizem Bal
    * Cemre Biltekin
    */   
   public static void main( String[] args) {
      
      //variables
      Scanner scan = new Scanner( System.in);
      Hangman game = new Hangman();
      
      
      //program code
      
      System.out.println("Welcome to the Hangman game");
      
      //the game loop
      while( !game.isGameOver() ) {
         
         //prints the available letters
         
         System.out.println("available letters: " + game.getAllLetters() + "\n" );
         
         //prints the knownsofar, used letters and tries left
         System.out.println("the word: " + game.getKnownSoFar() + "\n" );
             
         System.out.println("Used letters: " + game.getUsedLetters() + "\n" );
         
         System.out.println("You have " + (game.getMaxAllowedIncorrectTries 
                                              - game.getNumOfIncorrectTries()) 
                               + " tries left");
         
         //asks for next guess
         System.out.println("Try a letter from the list: ");
         game.tryThis( scan.next().charAt(0));
      }
      
      //informs the user if he/she won or not
      if ( game.hasLost() ) {
         Systen.out.println(" You lost :( ");
         //if secret word is not private
         //System.out.println("the word was: " + game.secretWord);
      }
      else {
         System.out.prinltn("You won!");
         System.out.println("the word was: " + game.getKnownSoFar() + "\n" );
      }
      
      
   }
} //end class