/**
 * Cem Ak�akaya 21401932
 * Hammad Musakhel  21801175
 * Mehmet Ali Erol 21703410
 * Maryam Shahid 21801344
 * Ece �nal 21703149
 * Yi�it Din� 21704275
 */
public class Hangman {
  
  public Hangman() { 

    StringBuffer secretWord;
    StringBuffer allLetters;
    StringBuffer knownSoFar;
    char[] alphabet;
    int maxAllowedIncorrectTries;
    int numberOfIncorrectTries;
    
    secretWord = new StringBuffer();
    allLetters = new StringBuffer(26);
    alphabet = new char[26];
    int index = 0;
    secretWord.append(chooseSecretWord());
    for(char c= 'a'; c <= 'z'; c++) {
      alphabet[index++] = c;
    }
    allLetters.append(alphabet);
    maxAllowedIncorrectTries = 6;
    numberOfIncorrectTries = 0;
    
    for ( int i = 0; i < secretWord.length(); i++)
    {
      knownSoFar.append('*');
    }
    
  }
  
}
